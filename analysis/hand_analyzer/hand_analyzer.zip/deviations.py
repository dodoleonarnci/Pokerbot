"""The four deviation tests, the pool summary, and report.md. Verdicts appear only on usable cells."""

import math

from backoff import BET_SIZE_VERDICT, USABLE

BLUFF = ("air", "draw")
WEAK = ("air", "draw", "weak")
PULL = BET_SIZE_VERDICT


def summary(tree, shows, meta) -> dict:
    seen = [node for node in tree.values() if node["n"]]
    counts = sorted((node["n"] for node in seen), reverse=True)
    half, running, decisions = 0, 0, sum(counts)
    for count in counts:
        running += count
        half += 1
        if running * 2 >= decisions:
            break
    class_cells = usable_cc = big_cc = 0
    split_cells = usable_split = big_split = 0
    split_decisions = 0
    class3_seen = set()
    for node in seen:
        per_class = {}
        for table in node["cls"].values():
            for cls, count in table.items():
                per_class[cls] = per_class.get(cls, 0) + count
        class_cells += len(per_class)
        for count in per_class.values():
            usable_cc += count >= USABLE
            big_cc += count >= BET_SIZE_VERDICT
        if node["k"].startswith("preflop") and node["n"]:
            class3_seen.update(per_class)
        for cell in node.get("splits", {}).values():
            split_cells += 1
            if cell["n"] >= USABLE:
                usable_split += 1
                split_decisions += cell["n"]
            big_split += cell["n"] >= BET_SIZE_VERDICT
    postflop = meta["postflop"] or 1
    return {
        "hands": meta["hands"], "errors": meta["errors"], "conservation_failures": meta["conservation"],
        "decisions": decisions,
        "path_nodes": len(seen), "path_nodes_20": sum(c >= USABLE for c in counts),
        "path_nodes_200": sum(c >= BET_SIZE_VERDICT for c in counts),
        "node_class_cells": class_cells, "node_class_cells_20": usable_cc, "node_class_cells_200": big_cc,
        "show_nodes": len(shows), "show_nodes_20": sum(s["n"] >= USABLE for s in shows.values()),
        "show_nodes_200": sum(s["n"] >= BET_SIZE_VERDICT for s in shows.values()),
        "split_cells": split_cells, "split_cells_20": usable_split, "split_cells_200": big_split,
        "postflop_decisions": meta["postflop"], "postflop_share_in_usable_cells": round(split_decisions / postflop, 4),
        "nodes_holding_half_of_decisions": half, "preflop_classes_seen": len(class3_seen),
    }


def z_score(rate, threshold, n):
    spread = threshold * (1 - threshold) / n if n else 0
    return (rate - threshold) / math.sqrt(spread) if spread > 0 else 0.0


def key_parts(key):
    parts = key.split(";")
    return parts + [""] * (6 - len(parts))


def _street_fold(pool):
    """Fold rate by street and size code faced, the parent for a bet that needs a response rate."""
    totals = {}
    for key, table in pool["responses"].items():
        street, _, code = key.split(";")
        cell = totals.setdefault((street, code), [0, 0])
        cell[0] += sum(table.values())
        cell[1] += table.get("f", 0)
    return totals


def pull(rate, n, parent):
    """Below 200 samples a bet-size verdict uses a rate pulled toward the parent."""
    if n >= PULL or parent is None:
        return rate
    return (n * rate + PULL * parent) / (n + PULL)


def _mix_share(table, names):
    total = sum(table.values())
    return sum(table.get(name, 0) for name in names) / total if total else None, total


def deviation_tests(tree, pool):
    """Returns verdict rows: test, spot key, path, size, n, observed, threshold, z, edge, chips."""
    spots = pool["spots"]
    parent_fold = _street_fold(pool)
    rows = []
    for node_key, node in tree.items():
        n = node["n"]
        implied = node.get("if", 0)
        if n + implied < USABLE:
            continue
        key = node["k"]
        street = key.split(";", 1)[0]
        path = node_key.rsplit(" @", 1)[0] if " @" in node_key else ""
        pot_bb = node["pot"]
        if "fb" in node:
            B, P = node["fb"], node["fp"]
            size = _faced_size(path)
            decisions = n + implied
            f = (node["a"].get("f", 0) + implied) / decisions
            threshold = B / (P + B) if P + B else 0.0
            z = z_score(f, threshold, decisions)
            edge = (f * P - (1 - f) * B) / P if P else 0.0
            chips = edge * max(pot_bb, P)
            if f > threshold and z >= 2:
                rows.append(("folds_too_much", key, path, size, decisions, f, threshold, z, edge, chips))
            elif f < threshold and z <= -2 and street != "preflop":
                call_mix = node["cls"].get("c", {})
                share, known = _mix_share(call_mix, WEAK)
                if known >= USABLE and share > 0.5:
                    rows.append(("calls_too_much", key, path, size, decisions, share, 0.5, z,
                                 -edge, -chips))
        if street == "preflop":
            continue
        parent = spots.get(key, {}).get("cls", {})
        for code, (count, b_sum, p_sum) in node.get("s", {}).items():
            B, P = b_sum / count, p_sum / count
            threshold = B / (P + 2 * B) if P + 2 * B else 0.0
            table = node["cls"].get(code, {})
            share, known = _mix_share(table, BLUFF)
            if known < USABLE:
                continue
            parent_share = _mix_share(parent.get(code, {}), BLUFF)[0]
            used = pull(share, known, parent_share)
            z = z_score(used, threshold, known)
            faced = parent_fold.get((street, code))
            f = faced[1] / faced[0] if faced and faced[0] else 0.0
            if used > threshold and z >= 2:
                edge = (f * P - (1 - f) * B) / P if P else 0.0
                rows.append(("bluffs_too_much", key, path, code, known, used, threshold, z, edge, edge * P))
            elif used < threshold and z <= -2:
                edge = _value_edge(node, code, f, B, P)
                rows.append(("value_too_much", key, path, code, known, used, threshold, z, edge, edge * P))
    rows.sort(key=lambda row: (-abs(row[9]), row[0], row[2], row[3]))
    return rows


def _value_edge(node, code, f, B, P):
    """c*(E_called(h)*(P+2B)-B), in pots, for the commonest value class in the node."""
    best = None
    for r_key, (called, share_sum) in node.get("ec", {}).items():
        if r_key.startswith(code + "#") and r_key.rsplit("#", 1)[1] in ("top", "strong"):
            if best is None or called > best[0]:
                best = (called, share_sum / called)
    if best is None or not P:
        return 0.0
    return (1 - f) * (best[1] * (P + 2 * B) - B) / P


def _faced_size(path):
    for token in reversed(path.replace(" /", "").split(" ")):
        code = token.split(":")[-1]
        if code and code[0] in "br":
            return code
    return "blind"


def pool_rates(pool, shows) -> dict:
    """Pool-wide rates, generic to any data: the numbers a planted-leak check reads from the report."""
    opens, three, by_street = {}, {"n": 0, "r": 0, "c": 0}, {}
    vs3 = {"n": 0, "f": 0, "c": 0, "r": 0}
    vs4 = {"n": 0, "f": 0, "c": 0, "r": 0}
    for key, spot in pool["spots"].items():
        street, line, pos = key.split(";")[:3]
        if street != "preflop":
            continue
        a = spot["a"]
        raises = sum(v for k, v in a.items() if k[0] == "r")
        if line == "unopened":
            cell = opens.setdefault(pos, {"n": 0, "r": 0, "c": 0})
            cell["n"] += spot["n"]
            cell["r"] += raises
            cell["c"] += a.get("c", 0)
        elif line == "vs_open":
            three["n"] += spot["n"]
            three["r"] += raises
            three["c"] += a.get("c", 0)
        elif line in ("vs_3bet", "vs_4bet+"):
            cell = vs3 if line == "vs_3bet" else vs4
            cell["n"] += spot["n"]
            cell["r"] += raises
            cell["c"] += a.get("c", 0)
            cell["f"] += a.get("f", 0)
    bet_by_class = {}
    for key, (n, bets) in pool["bet_class"].items():
        cls = key.split(";")[1]
        cell = bet_by_class.setdefault(cls, [0, 0])
        cell[0] += n
        cell[1] += bets
    fold_by_class = {}
    for key, table in pool["resp_class"].items():
        street, faced, prev, cls = key.split(";")
        if street != "flop" or faced[0] != "b" or faced[1] not in "SLO":
            continue
        group = "small" if faced[1] == "S" else "big"
        cell = fold_by_class.setdefault(f"{group};{cls}", [0, 0])
        cell[0] += sum(table.values())
        cell[1] += table.get("f", 0)
    lines = {}
    for key, table in pool["lines"].items():
        street, prev, faced = key.split(";")
        cell = lines.setdefault(f"{street};{prev}", [0, 0])
        cell[0] += sum(table.values())
        cell[1] += table.get("f", 0)
    pair_opp = sum(s["pair_opp"] for s in shows.values())
    pair_shown = sum(s["pair_shown"] for s in shows.values())
    discard_opp = sum(s["discard_opp"] for s in shows.values())
    bad = sum(s["bad_discard"] for s in shows.values())
    return {"open": opens, "vs_open": three, "vs_3bet": vs3, "vs_4bet": vs4, "bet_by_class": bet_by_class,
            "fold_by_class": fold_by_class, "two_street": lines,
            "show_helper": [pair_opp, pair_shown], "keep_best": [discard_opp, discard_opp - bad]}


def table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(cell).replace("|", "/") for cell in row) + " |")
    return "\n".join(lines) + "\n"


def _pct(n, part):
    return f"{part / n:.3f}" if n else "-"


def build_report(tree, shows, pool, meta, stats) -> str:
    out = ["# Hand analyzer report\n"]
    out.append(table(["Measure", "Value"], [(k, v) for k, v in stats.items()]))
    out.append(f"\nMalformed lines skipped: {meta['errors']} {meta['error_kinds']}\n")
    out.append("\n## Top 30 nodes by chips at stake\n\nChips at stake = decisions x average pot (BB).\n\n")
    ranked = sorted(((node["n"] * node["pot"], key) for key, node in tree.items() if node["n"]),
                    key=lambda item: (-item[0], item[1]))[:30]
    rows = []
    for chips, key in ranked:
        node = tree[key]
        parts = key_parts(node["k"])
        path = key.rsplit(" @", 1)[0] if " @" in key else "(start)"
        rows.append((parts[0], parts[1], node["actor"], parts[3], parts[4], parts[5], path, node["n"],
                     f"{node['pot']:.1f}", f"{chips:.0f}"))
    out.append(table(["Street", "Line", "Pos", "Players", "Depth", "So far", "Path", "n", "Pot BB", "Chips"], rows))

    verdicts = deviation_tests(tree, pool)
    names = {"folds_too_much": "Folds too much", "calls_too_much": "Calls too much",
             "bluffs_too_much": "Bluffs too much", "value_too_much": "Value bets too much"}
    out.append("\n## Deviation verdicts\n\nUsable cells only (20+ samples, |z| >= 2). A bet size with under "
               "200 samples is pulled toward its pooled spot. Edge is in pots; chips = edge x pot (BB).\n")
    for test, title in names.items():
        mine = [row for row in verdicts if row[0] == test]
        out.append(f"\n### {title}: {len(mine)} flagged, top 30\n\n")
        rows = []
        for _, key, path, size, n, observed, threshold, z, edge, chips in mine[:30]:
            parts = key_parts(key)
            rows.append((parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], path or "(start)", size, n,
                         f"{observed:.3f}", f"{threshold:.3f}", f"{z:.1f}", f"{edge:.3f}", f"{chips:.2f}"))
        out.append(table(["Street", "Line", "Pos", "Players", "Depth", "So far", "Path", "Size", "n", "Observed",
                          "Threshold", "z", "Edge", "Chips"], rows))

    rates = pool_rates(pool, shows)
    out.append("\n## Pool rates\n\n### Unopened, by position\n\n")
    out.append(table(["Pos", "n", "Open", "Limp"],
                     [(p, c["n"], _pct(c["n"], c["r"]), _pct(c["n"], c["c"])) for p, c in sorted(rates["open"].items())]))
    out.append("\n### Facing raises\n\n")
    out.append(table(["Spot", "n", "Fold", "Call", "Raise"],
                     [("vs_open", rates["vs_open"]["n"], _pct(rates["vs_open"]["n"], rates["vs_open"]["n"]
                                                             - rates["vs_open"]["c"] - rates["vs_open"]["r"]),
                       _pct(rates["vs_open"]["n"], rates["vs_open"]["c"]), _pct(rates["vs_open"]["n"], rates["vs_open"]["r"]))]
                     + [(name, c["n"], _pct(c["n"], c["f"]), _pct(c["n"], c["c"]), _pct(c["n"], c["r"]))
                        for name, c in (("vs_3bet", rates["vs_3bet"]), ("vs_4bet+", rates["vs_4bet"]))]))
    out.append("\n### Postflop bet frequency by class (no bet to face)\n\n")
    out.append(table(["Class", "n", "Bet"], [(k, v[0], _pct(v[0], v[1])) for k, v in sorted(rates["bet_by_class"].items())]))
    out.append("\n### Flop fold rate by bet size and class\n\n")
    out.append(table(["Size", "Class", "n", "Fold"],
                     [(*k.split(";"), v[0], _pct(v[0], v[1])) for k, v in sorted(rates["fold_by_class"].items())]))
    out.append("\n### Fold rate facing a first bet, by the previous street (two-street lines)\n\n")
    out.append(table(["Street", "Previous street", "n", "Fold"],
                     [(*k.split(";"), v[0], _pct(v[0], v[1])) for k, v in sorted(rates["two_street"].items())]))
    out.append("\n## Show and discard\n\n")
    out.append(table(["Measure", "Spots", "Rate"],
                     [("Shows the card that pairs the flop", rates["show_helper"][0], _pct(*rates["show_helper"])),
                      ("Keeps the best pair", rates["keep_best"][0], _pct(*rates["keep_best"]))]))
    out.append("\n### Top show-node leaks\n\nShowing the strong card (the kept card that pairs the flop) and bad "
               "discards (a better pair was available). Show nodes with 20+ samples only.\n\n")
    leaks = []
    for key, node in shows.items():
        if node["n"] < USABLE:
            continue
        pos, cls, bucket = key.split(";")
        shown_rate = node["pair_shown"] / node["pair_opp"] if node["pair_opp"] >= USABLE else None
        bad_rate = node["bad_discard"] / node["discard_opp"] if node["discard_opp"] >= USABLE else None
        score = max(shown_rate or 0, bad_rate or 0)
        leaks.append((score, key, pos, cls, bucket, node["n"], shown_rate, bad_rate))
    leaks.sort(key=lambda row: (-row[0], row[1]))
    out.append(table(["Pos", "Class", "Public bucket", "n", "Shows strong card", "Bad discard"],
                     [(p, c, b, n, "-" if s is None else f"{s:.3f}", "-" if d is None else f"{d:.3f}")
                      for _, _, p, c, b, n, s, d in leaks[:30]]))
    return "".join(out)
