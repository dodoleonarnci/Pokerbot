"""Reads canonical JSONL hands and writes tree.json, shows.json, pool.json and report.md.

Usage: analyze.py HANDS.jsonl --out DIR [--workers 2]
"""

import argparse
import gc
import json
import multiprocessing
import os
import time

from buckets import STRENGTH_ORDER, class3, pairs_board, pub_bucket, strength_class
from spot import MalformedHand, SpotTracker

try:
    import orjson

    loads = orjson.loads

    def dump_bytes(obj) -> bytes:
        return orjson.dumps(obj, option=orjson.OPT_SORT_KEYS)
except ImportError:
    loads = json.loads

    def dump_bytes(obj) -> bytes:
        return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()

# A node: [n, pot sum, actor, a, cls, r, facing bet sum, facing pot sum, facing n, implied folds,
#          s, ec, splits, first key].  A split cell: [n, pot sum, a, cls, r].
N, POT, ACTOR, A, CLS, R_, FB, FP, FN, IF, S, EC, SPLITS, KEY = range(14)


def empty_aggregate() -> dict:
    return {"nodes": {}, "shows": {}, "pool": {}, "bets": {}, "responses": {}, "resp_class": {},
            "bet_class": {}, "lines": {}, "hands": 0, "decisions": 0, "postflop": 0, "errors": 0,
            "conservation": 0, "error_kinds": {}}


def new_node(actor, key):
    return [0, 0.0, actor, {}, {}, {}, 0.0, 0.0, 0, 0, {}, {}, {}, key]


def bump(table, key):
    table[key] = table.get(key, 0) + 1


def known_cards(hand):
    """Per seat: (cards3 or None, kept2 or None), parsed by field name."""
    shows = hand.get("shows") or {}
    out = {}
    for entry in hand["seats"]:
        seat = entry["seat"]
        cards3, kept = entry.get("cards3"), entry.get("cards")
        show = shows.get(str(seat))
        if kept is None and cards3 and show and show.get("discard"):
            kept = [c for c in cards3 if c != show["discard"]]
        out[seat] = (tuple(cards3) if cards3 else None, tuple(kept) if kept else None)
    return out


def actor_class(street, cards, board_at):
    """The variant's hand class for an actor: 3-card class preflop, strength class after."""
    if street == 0:
        return class3(cards[0]) if cards[0] else None
    return strength_class(cards[1], board_at) if cards[1] else None


def play_hand(hand, agg):
    """Replays one hand and commits it to `agg`. Raises on a malformed hand before committing."""
    bb = hand["bb"]
    seats = hand["seats"]
    tracker = SpotTracker([(e["seat"], e["stack"]) for e in seats], hand["button"], hand.get("sb") or bb // 2,
                          bb, hand.get("ante") or 0)
    cards = known_cards(hand)
    board = hand.get("board") or []
    flop = board[:3]
    shows = hand.get("shows") or {}
    bucket = {}
    if flop:
        for seat_key, show in shows.items():
            if show.get("show"):
                bucket[int(seat_key)] = pub_bucket(show["show"], flop)
    boards = (None, tuple(board[:3]), tuple(board[:4]), tuple(board[:5]))
    decisions = []
    skipped = []
    active_bet = None  # The decision index of the latest bet or raise on this street.

    def skip_fold(actor_seat):
        i = tracker.actor
        skipped.append((tracker.path, tracker.pos[i], tracker.key, tracker.to_call / bb,
                        (tracker.pot - tracker.to_call) / bb, tracker.last_code, tracker.pot / bb))

    for action in hand["actions"]:
        street, seat, kind = action["street"], action["seat"], action["type"]
        while tracker.needs_implied_fold(seat, street):
            skip_fold(tracker.actor_seat)
            tracker.apply_implied_fold()
        i = tracker.actor
        if i is None:
            raise MalformedHand("action after the hand ended")
        path, pos, key, pot, to_call = tracker.path, tracker.pos[i], tracker.key, tracker.pot, tracker.to_call
        line = key.split(";", 2)[1]
        faced, prev = tracker.last_code, tracker.prev_line
        n_live = tracker.n_live
        put_before = tracker.put[i]
        other = None
        if street and n_live == 2:
            live = tracker.live
            for j in range(tracker.n):
                if live[j] and j != i:
                    other = tracker.seats[j]
        if kind == "fold" and street == 0 and not tracker.entered[i]:
            skip_fold(seat)
            tracker.apply(seat, kind, 0, street)
            continue
        code = tracker.apply(seat, kind, action.get("to", 0), street)
        cls = actor_class(street, cards[seat], boards[street]) if seat in cards else None
        added = tracker.put[i] - put_before
        decisions.append((path, pos, key, code, cls, pot, to_call, seat, put_before, added, line, faced, prev,
                          n_live, other, street, False))
        if code[0] in "br":
            active_bet = len(decisions) - 1
        elif code == "c" and active_bet is not None:
            d = decisions[active_bet]
            if d[15] == street and not d[16]:
                decisions[active_bet] = d[:16] + (True,)
    while tracker.can_imply_fold():
        skip_fold(tracker.actor_seat)
        tracker.apply_implied_fold()

    winnings = {int(k): v for k, v in (hand.get("winnings") or {}).items()}
    total_put = sum(tracker.put)
    if total_put != sum(winnings.values()):
        agg["conservation"] += 1
        raise MalformedHand("chips do not conserve")

    commit(agg, hand, tracker, decisions, skipped, winnings, cards, bucket, flop, bb, total_put)


def commit(agg, hand, tracker, decisions, skipped, winnings, cards, bucket, flop, bb, total_put):
    nodes = agg["nodes"]
    pool = agg["pool"]
    responses = agg["responses"]
    final_put = dict(zip(tracker.seats, tracker.put))
    for path, pos, key, tc, pot_before, faced, pot in skipped:
        node_key = f"{path} @{pos}" if path else f"@{pos}"
        node = nodes.get(node_key)
        if node is None:
            node = nodes[node_key] = new_node(pos, key)
        node[IF] += 1
        if tc > 0:
            node[FB] += tc
            node[FP] += pot_before
            node[FN] += 1
        spot = pool.get(key)
        if spot is None:
            spot = pool[key] = [0, 0.0, {}, {}]
        spot[0] += 1
        spot[1] += pot
        a = spot[2]
        a["f"] = a.get("f", 0) + 1
        response = responses.get(f"preflop;{pos};{faced}")
        if response is None:
            response = responses[f"preflop;{pos};{faced}"] = {}
        response["f"] = response.get("f", 0) + 1

    agg["hands"] += 1
    agg["decisions"] += len(decisions)
    for path, pos, key, code, cls, pot, to_call, seat, put_before, added, line, faced, prev, n_live, other, \
            street, called in decisions:
        node_key = f"{path} @{pos}" if path else f"@{pos}"
        node = nodes.get(node_key)
        if node is None:
            node = nodes[node_key] = new_node(pos, key)
        pot_bb = pot / bb
        node[N] += 1
        node[POT] += pot_bb
        a = node[A]
        a[code] = a.get(code, 0) + 1
        if to_call:
            node[FB] += to_call / bb
            node[FP] += (pot - to_call) / bb
            node[FN] += 1
        spot = pool.get(key)
        if spot is None:
            spot = pool[key] = [0, 0.0, {}, {}]
        spot[0] += 1
        spot[1] += pot_bb
        spot_a = spot[2]
        spot_a[code] = spot_a.get(code, 0) + 1
        collected = winnings.get(seat, 0)
        net = None
        if cls is not None:
            net = (collected - (final_put[seat] - put_before)) / pot
            cls_table = node[CLS].get(code)
            if cls_table is None:
                cls_table = node[CLS][code] = {}
            cls_table[cls] = cls_table.get(cls, 0) + 1
            r_key = f"{code}#{cls}"
            result = node[R_].get(r_key)
            if result is None:
                node[R_][r_key] = [1, net, net * net]
            else:
                result[0] += 1
                result[1] += net
                result[2] += net * net
            spot_cls = spot[3].get(code)
            if spot_cls is None:
                spot_cls = spot[3][code] = {}
            spot_cls[cls] = spot_cls.get(cls, 0) + 1
        is_bet = code[0] in "br"
        if is_bet:
            b = added - to_call
            size = node[S].get(code)
            if size is None:
                size = node[S][code] = [0, 0.0, 0.0]
            size[0] += 1
            size[1] += b / bb
            size[2] += (pot + to_call) / bb
            if called and cls is not None:
                ec = node[EC].get(r_key)
                if ec is None:
                    ec = node[EC][r_key] = [0, 0.0]
                ec[0] += 1
                ec[1] += collected / total_put
        if street == 0:
            if to_call:
                r_id = f"preflop;{pos};{faced}"
                response = responses.get(r_id)
                if response is None:
                    response = responses[r_id] = {}
                group = "r" if is_bet else code
                response[group] = response.get(group, 0) + 1
            continue
        agg["postflop"] += 1
        street_name = key[: key.index(";")]
        if is_bet:
            bump(agg["bets"], f"{street_name};{line};{pos};{code}")
        if to_call:
            group = "r" if is_bet else code
            r_id = f"{street_name};{pos};{faced}"
            response = responses.get(r_id)
            if response is None:
                response = responses[r_id] = {}
            response[group] = response.get(group, 0) + 1
            if line == "vs_bet":
                line_id = f"{street_name};{prev};{faced}"
                table = agg["lines"].get(line_id)
                if table is None:
                    table = agg["lines"][line_id] = {}
                table[group] = table.get(group, 0) + 1
            if cls is not None:
                rc_id = f"{street_name};{faced};{prev};{cls}"
                table = agg["resp_class"].get(rc_id)
                if table is None:
                    table = agg["resp_class"][rc_id] = {}
                table[group] = table.get(group, 0) + 1
        elif cls is not None:
            bc_id = f"{street_name};{cls}"
            table = agg["bet_class"].get(bc_id)
            if table is None:
                table = agg["bet_class"][bc_id] = [0, 0]
            table[0] += 1
            table[1] += is_bet
        mine = bucket.get(seat)
        if mine is None:
            continue
        if n_live == 2:
            theirs = bucket.get(other)
            if theirs is None:
                continue
        else:
            theirs = "M"
        split_key = f"{mine}|{theirs}"
        cell = node[SPLITS].get(split_key)
        if cell is None:
            cell = node[SPLITS][split_key] = [0, 0.0, {}, {}, {}]
        cell[0] += 1
        cell[1] += pot_bb
        cell_a = cell[2]
        cell_a[code] = cell_a.get(code, 0) + 1
        if cls is not None:
            cell_cls = cell[3].get(code)
            if cell_cls is None:
                cell_cls = cell[3][code] = {}
            cell_cls[cls] = cell_cls.get(cls, 0) + 1
            result = cell[4].get(r_key)
            if result is None:
                cell[4][r_key] = [1, net, net * net]
            else:
                result[0] += 1
                result[1] += net
                result[2] += net * net
    if flop:
        commit_shows(agg, hand, tracker, cards, flop, bucket)


def commit_shows(agg, hand, tracker, cards, flop, bucket):
    """One show node per player and hand that reached the flop, when the kept cards are known."""
    shows = agg["shows"]
    for seat_key, show in (hand.get("shows") or {}).items():
        seat = int(seat_key)
        known = cards.get(seat)
        if known is None or known[1] is None or not show.get("show"):
            continue
        kept = known[1]
        cls = strength_class(kept, flop)
        key = f"{tracker.pos[tracker.index[seat]]};{cls};{bucket[seat]}"
        node = shows.get(key)
        if node is None:
            node = shows[key] = [0, 0, 0, 0, 0]
        node[0] += 1
        shown = show["show"]
        other = kept[0] if kept[1] == shown else kept[1]
        if pairs_board(shown, flop) != pairs_board(other, flop):
            node[1] += 1
            node[2] += pairs_board(shown, flop)
        full = known[0]
        if full:
            order = STRENGTH_ORDER
            mine = order[cls]
            values = [order[strength_class(pair, flop)]
                      for pair in ((full[0], full[1]), (full[0], full[2]), (full[1], full[2]))]
            if min(values) != max(values):
                node[3] += 1
                node[4] += mine < max(values)


def process_chunk(args):
    path, start, end = args
    gc.disable()
    agg = empty_aggregate()
    errors = agg["error_kinds"]
    with open(path, "rb") as handle:
        handle.seek(start)
        data = handle.read(end - start)
    for line in data.split(b"\n"):
        if not line.strip():
            continue
        try:
            play_hand(loads(line), agg)
        except (MalformedHand, KeyError, TypeError, ValueError, IndexError, AttributeError,
                ZeroDivisionError) as error:
            agg["errors"] += 1
            bump(errors, type(error).__name__)
    return agg


def chunks(path: str, count: int):
    """Byte ranges split at line ends."""
    size = os.path.getsize(path)
    cuts = [0]
    with open(path, "rb") as handle:
        for i in range(1, count):
            handle.seek(size * i // count)
            handle.readline()
            cuts.append(min(handle.tell(), size))
    cuts.append(size)
    return [(path, cuts[i], cuts[i + 1]) for i in range(count) if cuts[i + 1] > cuts[i]]


def merge_counts(into, other):
    for key, value in other.items():
        into[key] = into.get(key, 0) + value


def merge_nested(into, other):
    for key, value in other.items():
        table = into.get(key)
        if table is None:
            into[key] = value
        else:
            merge_counts(table, value)


def merge_results(into, other):
    for key, value in other.items():
        cell = into.get(key)
        if cell is None:
            into[key] = value
        else:
            cell[0] += value[0]
            cell[1] += value[1]
            cell[2] += value[2]


def merge(into, other):
    nodes = into["nodes"]
    for key, node in other["nodes"].items():
        mine = nodes.get(key)
        if mine is None:
            nodes[key] = node
            continue
        mine[N] += node[N]
        mine[POT] += node[POT]
        merge_counts(mine[A], node[A])
        merge_nested(mine[CLS], node[CLS])
        merge_results(mine[R_], node[R_])
        mine[FB] += node[FB]
        mine[FP] += node[FP]
        mine[FN] += node[FN]
        mine[IF] += node[IF]
        merge_results(mine[S], node[S])
        for r_key, ec in node[EC].items():
            cell = mine[EC].get(r_key)
            if cell is None:
                mine[EC][r_key] = ec
            else:
                cell[0] += ec[0]
                cell[1] += ec[1]
        splits = mine[SPLITS]
        for split_key, cell in node[SPLITS].items():
            own = splits.get(split_key)
            if own is None:
                splits[split_key] = cell
            else:
                own[0] += cell[0]
                own[1] += cell[1]
                merge_counts(own[2], cell[2])
                merge_nested(own[3], cell[3])
                merge_results(own[4], cell[4])
    for key, node in other["shows"].items():
        mine = into["shows"].get(key)
        if mine is None:
            into["shows"][key] = node
        else:
            for i, value in enumerate(node):
                mine[i] += value
    for key, spot in other["pool"].items():
        mine = into["pool"].get(key)
        if mine is None:
            into["pool"][key] = spot
        else:
            mine[0] += spot[0]
            mine[1] += spot[1]
            merge_counts(mine[2], spot[2])
            merge_nested(mine[3], spot[3])
    merge_counts(into["bets"], other["bets"])
    merge_nested(into["responses"], other["responses"])
    merge_nested(into["resp_class"], other["resp_class"])
    merge_nested(into["lines"], other["lines"])
    for key, value in other["bet_class"].items():
        mine = into["bet_class"].get(key)
        if mine is None:
            into["bet_class"][key] = value
        else:
            mine[0] += value[0]
            mine[1] += value[1]
    for name in ("hands", "decisions", "postflop", "errors", "conservation"):
        into[name] += other[name]
    merge_counts(into["error_kinds"], other["error_kinds"])


def to_tree(nodes):
    tree = {}
    for key, node in nodes.items():
        n = node[N]
        out = {"n": n, "actor": node[ACTOR], "pot": node[POT] / n if n else 0.0, "a": node[A], "cls": node[CLS],
               "r": node[R_], "k": node[KEY]}
        if node[IF]:
            out["if"] = node[IF]
        if node[FN]:
            out["fb"] = node[FB] / node[FN]
            out["fp"] = node[FP] / node[FN]
        if node[S]:
            out["s"] = node[S]
        if node[EC]:
            out["ec"] = node[EC]
        if node[SPLITS]:
            out["splits"] = {k: {"n": c[0], "pot": c[1] / c[0], "a": c[2], "cls": c[3], "r": c[4]}
                             for k, c in node[SPLITS].items()}
        tree[key] = out
    return tree


def analyze(path, out_dir, workers=2, quiet=False):
    begun = time.perf_counter()
    os.makedirs(out_dir, exist_ok=True)
    ranges = chunks(path, workers)
    if workers > 1 and len(ranges) > 1:
        with multiprocessing.Pool(workers) as pool:
            parts = pool.map(process_chunk, ranges, chunksize=1)
    else:
        parts = [process_chunk(r) for r in ranges]
    phases = {"map": time.perf_counter() - begun}
    gc.disable()
    agg = parts[0] if parts else empty_aggregate()
    for part in parts[1:]:
        merge(agg, part)
    phases["merge"] = time.perf_counter() - begun
    tree = to_tree(agg["nodes"])
    shows = {k: {"n": v[0], "pair_opp": v[1], "pair_shown": v[2], "discard_opp": v[3], "bad_discard": v[4]}
             for k, v in agg["shows"].items()}
    spots = {k: {"n": v[0], "pot": v[1] / v[0], "a": v[2], "cls": v[3]} for k, v in agg["pool"].items()}
    pool = {"spots": spots, "bets": agg["bets"], "responses": agg["responses"], "lines": agg["lines"],
            "resp_class": agg["resp_class"], "bet_class": agg["bet_class"]}
    meta = {k: agg[k] for k in ("hands", "decisions", "postflop", "errors", "conservation", "error_kinds")}
    from deviations import build_report, summary
    stats = summary(tree, shows, meta)
    report = build_report(tree, shows, pool, meta, stats)
    phases["report"] = time.perf_counter() - begun
    for name, obj in (("tree.json", tree), ("shows.json", shows), ("pool.json", pool)):
        with open(os.path.join(out_dir, name), "wb") as handle:
            handle.write(dump_bytes(obj))
    with open(os.path.join(out_dir, "report.md"), "w") as handle:
        handle.write(report)
    phases["write"] = time.perf_counter() - begun
    stats["seconds"] = round(time.perf_counter() - begun, 1)
    stats["phase_seconds_cumulative"] = {k: round(v, 1) for k, v in phases.items()}
    if not quiet:
        print(json.dumps(stats, indent=1))
    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("hands")
    parser.add_argument("--out", default="out")
    parser.add_argument("--workers", type=int, default=2)
    options = parser.parse_args()
    analyze(options.hands, options.out, options.workers)
