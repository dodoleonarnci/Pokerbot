"""Estimates what opponents folded, using the EM in analysis/pineapple_em (imported unchanged).

Usage (NumPy venv): ~/work/analysis/.venv/bin/python em_folds.py HANDS.jsonl --out DIR

Each opponent who reaches the flop has one card we may never see. The EM fits how often each hand
class takes each action at each spot, using exposed cards, every action, and showdowns, then gives
a probability for each hand class at every decision, folds included. Spots are pooled across positions
to fit; the results keep positions apart. Writes em_folds.json and em_folds.md.
"""

import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pineapple_em import em  # noqa: E402
from pineapple_em.cards import N_BUCKETS, BoardView, bucket, parse_card  # noqa: E402

from spot import SpotTracker  # noqa: E402

# The EM's six buckets, in order, as the analyzer's five classes.
CLASS_OF = ("air", "air", "draw", "weak", "top", "strong")
CLASSES = ("air", "draw", "weak", "top", "strong")
_INDEX = {name: i for i, name in enumerate(CLASSES)}
TO_CLASS = np.zeros((N_BUCKETS, len(CLASSES)))
for _bucket, _name in enumerate(CLASS_OF):
    TO_CLASS[_bucket, _INDEX[_name]] = 1.0
ACTIONS = {"x": 0, "f": 1, "c": 2, "S": 3, "M": 4, "L": 5, "O": 6}
N_ACTIONS = len(ACTIONS)
N_LINES = 2


def replay(hand):
    """(seat, node label, action code, street, path key, line, position, faced, chance) per postflop decision."""
    bb = hand["bb"]
    tracker = SpotTracker([(e["seat"], e["stack"]) for e in hand["seats"]], hand["button"], hand.get("sb") or bb // 2,
                          bb, hand.get("ante") or 0)
    out = []
    for action in hand["actions"]:
        street, seat = action["street"], action["seat"]
        while tracker.needs_implied_fold(seat, street):
            tracker.apply_implied_fold()
        i = tracker.actor
        if street == 0:
            tracker.apply(seat, action["type"], action.get("to", 0), street)
            continue
        line, pos, path, faced = tracker.line(), tracker.pos[i], tracker.path, tracker.last_code
        players = "HU" if tracker.n_live == 2 else "MW"
        node = f"{street};{players};{line};{faced[1:] if faced else ''}"
        pot, to_call = tracker.pot, tracker.to_call
        put = tracker.put[i]
        code = tracker.apply(seat, action["type"], action.get("to", 0), street)
        price = tracker.put[i] - put - to_call if code[0] in "br" else 0
        out.append((seat, node, code, street, f"{path} @{pos}", line, pos, faced, price, pot + to_call))
    pfr = tracker.seats[tracker.pfr] if tracker.pfr is not None else None
    return out, pfr, set(tracker.live_seats()), tracker


def observations(hands, include_excluded=False):
    """EM inputs for each opponent at each flop, plus one metadata row per decision, in EM group order."""
    node_ids, obs, meta = {}, [], []
    for hand in hands:
        board_text = hand.get("board") or []
        if len(board_text) < 3 or not hand.get("shows"):
            continue
        decisions, pfr, _, _ = replay(hand)
        excluded = set() if include_excluded else set(hand.get("exclude") or ())
        board = tuple(parse_card(c) for c in board_text)
        seats = {e["seat"]: e for e in hand["seats"]}
        shows = hand["shows"]
        exposed = {int(s): parse_card(v["show"]) for s, v in shows.items() if v.get("show")}
        known = {s: [parse_card(c) for c in seats[s]["cards"]] for s in exposed if seats[s].get("cards")}
        own = {parse_card(c) for s in excluded for c in seats[s].get("cards3", [])}
        for seat, card in exposed.items():
            if seat in excluded:
                continue
            mine = [d for d in decisions if d[0] == seat]
            if not mine:
                continue
            others = {c for s, cards in known.items() if s != seat for c in cards}
            blocked = frozenset(own | others | (set(exposed.values()) - {card}))
            hidden = None
            if seat in known and card in known[seat]:
                hidden = next((c for c in known[seat] if c != card), card)
                if hidden == card:
                    hidden = None
            rows = []
            for d in mine:
                code = d[2]
                action = ACTIONS[code[1] if code[0] in "br" else code]
                rows.append((node_ids.setdefault(d[1], len(node_ids)), action, d[3] - 1))
                meta.append(d)
            obs.append(em.Observation(0 if pfr == seat else 1, card, board, blocked, tuple(rows), hidden))
    return obs, node_ids, meta


def fit(obs, node_ids):
    arrays = em.build(obs)
    model = em.fit(arrays, len(node_ids), N_ACTIONS, N_LINES)
    return model, em.decision_bucket_mix(model, arrays) @ TO_CLASS, arrays


def known_mix(obs):
    """A one-hot class row per decision where the card was shown; NaN where it was not."""
    rows = []
    for o in obs:
        for _, _, street in o.decisions:
            if o.hidden is None:
                rows.append([np.nan] * len(CLASSES))
            else:
                row = [0.0] * len(CLASSES)
                row[_INDEX[CLASS_OF[bucket(o.exposed, o.hidden, BoardView(o.board[:3 + street]))]]] = 1.0
                rows.append(row)
    return np.array(rows)


def size_of(faced):
    return faced[1] if len(faced) > 1 else ""


def tables(meta, mix, shown):
    """Fold rates and hand mixes from the estimated class probability of every decision."""
    street_names = {1: "flop", 2: "turn", 3: "river"}
    response, folded, bets, nodes = {}, {}, {}, {}
    for d, row, seen in zip(meta, mix, shown):
        _, _, code, street, path_key, line, pos, faced, price, pot_after = d
        name = street_names[street]
        node = nodes.setdefault(path_key, {"n": 0, "a": {}})
        node["n"] += 1
        table = node["a"].setdefault(code, [0.0] * len(CLASSES))
        for i, value in enumerate(row):
            table[i] += float(value)
        facing = faced[:1] in ("b", "r")
        if facing:
            cell = response.setdefault((name, size_of(faced)), {"mass": np.zeros(5), "fold": np.zeros(5), "n": 0, "f": 0,
                                                                "seen": np.zeros(5), "seen_fold": np.zeros(5), "seen_f": 0})
            is_fold = code == "f"
            cell["mass"] += row
            cell["n"] += 1
            cell["f"] += is_fold
            has_card = not np.isnan(seen[0])
            if has_card:
                cell["seen"] += seen
            if is_fold:
                cell["fold"] += row
                if has_card:
                    cell["seen_fold"] += seen
                    cell["seen_f"] += 1
                by_pos = folded.setdefault((name, pos, size_of(faced)), [np.zeros(5), 0])
                by_pos[0] += row
                by_pos[1] += 1
        if code[0] in "br":
            cell = bets.setdefault((name, line, code[1]), {"mass": np.zeros(5), "n": 0, "seen": np.zeros(5), "seen_n": 0,
                                                           "b": 0.0, "p": 0.0})
            cell["mass"] += row
            cell["n"] += 1
            cell["b"] += price
            cell["p"] += pot_after
            if not np.isnan(seen[0]):
                cell["seen"] += seen
                cell["seen_n"] += 1
    return response, folded, bets, nodes


def _table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    lines += ["| " + " | ".join(str(c) for c in row) + " |" for row in rows]
    return "\n".join(lines) + "\n"


def _shares(values):
    total = values.sum()
    return [f"{v / total:.3f}" if total else "-" for v in values]


def write_outputs(out_dir, meta_info, response, folded, bets, nodes):
    os.makedirs(out_dir, exist_ok=True)
    order = {"S": 0, "M": 1, "L": 2, "O": 3, "": 4}
    payload = {
        "info": meta_info, "classes": CLASSES,
        "fold_rate_by_class": {f"{s};{z}": {
            "n": c["n"], "fold_rate": c["f"] / c["n"],
            "by_class": {name: float(c["fold"][i] / c["mass"][i]) if c["mass"][i] else None
                         for i, name in enumerate(CLASSES)},
            "folded_mix": {name: float(c["fold"][i] / c["f"]) if c["f"] else None for i, name in enumerate(CLASSES)}}
            for (s, z), c in response.items()},
        "folded_by_position": {f"{s};{p};{z}": {"n": n, "mix": {name: float(v[i] / n) for i, name in enumerate(CLASSES)}}
                               for (s, p, z), (v, n) in folded.items()},
        "bets": {f"{s};{l};{z}": {"n": c["n"], "mix": {name: float(c["mass"][i] / c["n"]) for i, name in enumerate(CLASSES)}}
                 for (s, l, z), c in bets.items()},
        "nodes": {key: {"n": node["n"], "a": {code: dict(zip(CLASSES, values)) for code, values in node["a"].items()}}
                  for key, node in nodes.items()},
    }
    with open(os.path.join(out_dir, "em_folds.json"), "w") as handle:
        json.dump(payload, handle, sort_keys=True, separators=(",", ":"))
    rows = []
    for (street, size), c in sorted(response.items(), key=lambda kv: (("flop", "turn", "river").index(kv[0][0]), order.get(kv[0][1], 9))):
        rate = [f"{c['fold'][i] / c['mass'][i]:.3f}" if c["mass"][i] > 1 else "-" for i in range(5)]
        rows.append((street, size, c["n"], f"{c['f'] / c['n']:.3f}", *rate))
    out = ["# What opponents folded (EM estimate)\n\n",
           f"Opponents only: {meta_info['opponent_flop_lines']} lines, {meta_info['decisions']} postflop decisions, "
           f"{meta_info['folds']} folds, of which {meta_info['folds_with_cards']} have known cards. "
           f"EM stopped after {meta_info['iterations']} iterations. These are model estimates, not observed cards.\n\n",
           "## Fold rate by hand class and bet size faced\n\n",
           _table(("Street", "Size", "n", "All", *CLASSES), rows), "\n## What the folded hands were\n\n"]
    rows = []
    for (street, size), c in sorted(response.items(), key=lambda kv: (("flop", "turn", "river").index(kv[0][0]), order.get(kv[0][1], 9))):
        if c["f"]:
            rows.append((street, size, c["f"], *_shares(c["fold"]), int(c["seen_f"])))
    out.append(_table(("Street", "Size", "Folds", *CLASSES, "Shown"), rows))
    out.append("\n## Folded hands by position (50+ folds)\n\n")
    rows = [(s, p, z, n, *_shares(v)) for (s, p, z), (v, n) in
            sorted(folded.items(), key=lambda kv: (("flop", "turn", "river").index(kv[0][0]), kv[0][1], order.get(kv[0][2], 9))) if n >= 50]
    out.append(_table(("Street", "Pos", "Size", "Folds", *CLASSES), rows))
    out.append("\n## Bluff share behind bets and raises (20+)\n\nBluff = air + draw. Balance = B/(P+2B). Shown-only is "
               "the same share from hands that reached showdown, the sample the count-based report has.\n\n")
    rows = []
    for (street, line, size), c in sorted(bets.items(), key=lambda kv: (("flop", "turn", "river").index(kv[0][0]), kv[0][1], order.get(kv[0][2], 9))):
        if c["n"] < 20:
            continue
        b, p = c["b"] / c["n"], c["p"] / c["n"]
        bluff = (c["mass"][0] + c["mass"][1]) / c["n"]
        seen = (c["seen"][0] + c["seen"][1]) / c["seen_n"] if c["seen_n"] else None
        rows.append((street, line, size, c["n"], f"{bluff:.3f}", "-" if seen is None else f"{seen:.3f}", c["seen_n"],
                     f"{b / (p + 2 * b):.3f}" if p + 2 * b else "-"))
    out.append(_table(("Street", "Line", "Size", "n", "EM bluff", "Shown-only bluff", "Shown n", "Balance"), rows))
    with open(os.path.join(out_dir, "em_folds.md"), "w") as handle:
        handle.write("".join(out))


def read_hands(path, limit=None):
    with open(path, "rb") as source:
        for count, line in enumerate(source):
            if limit and count >= limit:
                return
            yield json.loads(line)


def run(path, out_dir, limit=None, include_excluded=False):
    begun = time.perf_counter()
    obs, node_ids, meta = observations(read_hands(path, limit), include_excluded)
    model, mix, arrays = fit(obs, node_ids)
    shown = known_mix(obs)
    response, folded, bets, nodes = tables(meta, mix, shown)
    folds = [i for i, d in enumerate(meta) if d[2] == "f"]
    info = {"opponent_flop_lines": len(obs), "decisions": len(meta), "folds": len(folds),
            "folds_with_cards": int(np.sum(~np.isnan(shown[folds, 0]))) if folds else 0, "iterations": model.iterations,
            "nodes": len(node_ids), "rows": int(len(arrays.row_cell)), "log_likelihood": model.log_likelihood,
            "seconds": round(time.perf_counter() - begun, 1)}
    write_outputs(out_dir, info, response, folded, bets, nodes)
    print(json.dumps(info, indent=1))
    return info


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("hands")
    parser.add_argument("--out", required=True)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--include-excluded", action="store_true")
    options = parser.parse_args()
    run(options.hands, options.out, options.limit, options.include_excluded)
