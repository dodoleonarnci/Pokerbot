"""Checks the folded-hand EM against generated hands whose folded cards are known.

Hides every card except at showdown, as a real download does, then scores the estimates against the
truth. Run with the NumPy venv from the project folder:
~/work/analysis/.venv/bin/python tests/test_em_folds.py data/hands250k.jsonl [HANDS]
"""

import copy
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import em_folds as ef  # noqa: E402


def hide_unshown(hand):
    """Keeps kept cards only for seats still in at the end of a hand that went to showdown."""
    hand = copy.deepcopy(hand)
    _, _, live, _ = ef.replay(hand)
    went_to_showdown = len(live) >= 2 and len(hand.get("board") or []) == 5
    for entry in hand["seats"]:
        entry.pop("cards3", None)
        if not (went_to_showdown and entry["seat"] in live):
            entry.pop("cards", None)
    for show in (hand.get("shows") or {}).values():
        show.pop("discard", None)
    return hand


def main():
    path = sys.argv[1]
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 60000
    # Only hands with all cards visible give a truth row for every decision.
    full = [h for h in ef.read_hands(path, limit)
            if all("cards" in e for e in h["seats"] if str(e["seat"]) in (h.get("shows") or {}))]
    hidden = [hide_unshown(h) for h in full]
    truth_obs, _, truth_meta = ef.observations(full)
    obs, node_ids, meta = ef.observations(hidden)
    assert [m[:4] for m in truth_meta] == [m[:4] for m in meta]
    truth = ef.known_mix(truth_obs)
    seen = ef.known_mix(obs)
    _, mix, _ = ef.fit(obs, node_ids)
    assert not np.isnan(truth).any()
    codes = np.array([m[2] for m in meta])
    streets = np.array([m[3] for m in meta])
    faced = np.array([m[7][:1] in ("b", "r") for m in meta])
    folds = codes == "f"
    print(f"{len(obs)} lines, {len(meta)} decisions, {folds.sum()} folds, "
          f"{np.sum(~np.isnan(seen[folds, 0]))} folds with known cards")
    print("\nWhat folded hands were (share by class)")
    print(f"{'':<8}{'':<14}" + "".join(f"{c:>9}" for c in ef.CLASSES))
    worst = 0.0
    for street, name in ((1, "flop"), (2, "turn"), (3, "river")):
        pick = folds & (streets == street)
        true_mix, em_mix = truth[pick].mean(0), mix[pick].mean(0)
        worst = max(worst, np.abs(true_mix - em_mix).max())
        print(f"{name:<8}{'truth':<14}" + "".join(f"{v:9.3f}" for v in true_mix))
        print(f"{'':<8}{'EM':<14}" + "".join(f"{v:9.3f}" for v in em_mix))
    print("\nFold rate by true class, facing a bet (truth, EM, showdown cards only)")
    for street, name in ((1, "flop"), (2, "turn"), (3, "river")):
        pick = faced & (streets == street)
        true_rate = (truth[pick] * folds[pick, None]).sum(0) / truth[pick].sum(0)
        em_rate = (mix[pick] * folds[pick, None]).sum(0) / mix[pick].sum(0)
        has = pick & ~np.isnan(seen[:, 0])
        naive = (seen[has] * folds[has, None]).sum(0) / np.maximum(seen[has].sum(0), 1)
        print(f"{name:<8}{'truth':<14}" + "".join(f"{v:9.3f}" for v in true_rate))
        print(f"{'':<8}{'EM':<14}" + "".join(f"{v:9.3f}" for v in em_rate))
        print(f"{'':<8}{'shown only':<14}" + "".join(f"{v:9.3f}" for v in naive))
    bets = np.array([c[0] in "br" for c in codes])
    print("\nBluff share behind bets (air + draw)")
    for street, name in ((1, "flop"), (2, "turn"), (3, "river")):
        pick = bets & (streets == street)
        has = pick & ~np.isnan(seen[:, 0])
        print(f"{name:<8}truth {truth[pick][:, :2].sum(1).mean():.3f}  EM {mix[pick][:, :2].sum(1).mean():.3f}  "
              f"shown only {seen[has][:, :2].sum(1).mean():.3f}")
    print(f"\nLargest error in a folded-hand share: {worst:.3f}")


if __name__ == "__main__":
    main()
